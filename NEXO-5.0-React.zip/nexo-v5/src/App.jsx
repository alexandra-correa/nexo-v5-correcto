import React, { useEffect, useMemo, useState } from "react";
import {
  Activity, Bell, Check, CheckCheck, ChevronDown, CircleHelp, Clock3,
  Coffee, CreditCard, Download, LayoutDashboard, LogOut, Menu, MoreHorizontal,
  Plus, QrCode, Search, Settings, ShieldCheck, SlidersHorizontal, Sparkles,
  Table2, Users, Utensils, Wallet, X, Zap, ArrowUpRight, CircleCheck,
  CircleAlert, Timer, Smartphone, ClipboardList, ChefHat, MessageSquare,
  TrendingUp, CalendarDays, Filter, ExternalLink, Copy, RefreshCw
} from "lucide-react";

const STORAGE_KEY = "nexo-v5-state";
const initialTables = Array.from({ length: 12 }, (_, i) => ({
  id: i + 1, seats: i < 4 ? 2 : i < 9 ? 4 : 6,
  zone: i < 6 ? "Terraza" : "Salón", status: "libre"
}));
const seedRequests = [
  { id: 1001, table: 3, type: "atencion", note: "Necesito hacer una consulta", status: "pendiente", createdAt: Date.now() - 1000 * 60 * 2, assigned: "Sin asignar" },
  { id: 1002, table: 7, type: "cuenta", note: "Solicita la cuenta", status: "en proceso", createdAt: Date.now() - 1000 * 60 * 6, assigned: "Camila" },
  { id: 1003, table: 2, type: "pedido", note: "Solicita realizar un pedido", status: "pendiente", createdAt: Date.now() - 1000 * 60 * 9, assigned: "Sin asignar" }
];
const defaultState = {
  restaurant: { name: "Casa NEXO", subtitle: "Restaurante & Café", currency: "USD", timezone: "America/Caracas" },
  tables: initialTables,
  requests: seedRequests,
  staff: [
    { id: 1, name: "Camila", role: "Camarera", active: true },
    { id: 2, name: "Andrés", role: "Camarero", active: true },
    { id: 3, name: "Valentina", role: "Administradora", active: true }
  ],
  settings: { sound: true, autoAssign: false, serviceHours: "09:00 – 22:00" }
};

function loadState() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? { ...defaultState, ...JSON.parse(saved) } : defaultState;
  } catch { return defaultState; }
}
const timeAgo = (timestamp) => {
  const mins = Math.max(0, Math.floor((Date.now() - timestamp) / 60000));
  if (mins < 1) return "Ahora";
  if (mins === 1) return "Hace 1 min";
  return `Hace ${mins} min`;
};
const fmtTime = (timestamp) => new Date(timestamp).toLocaleTimeString("es-CL", { hour: "2-digit", minute: "2-digit" });
const requestLabel = (type) => ({ atencion: "Llamar al camarero", cuenta: "Solicitar cuenta", pedido: "Hacer un pedido" }[type] || type);
const statusClass = (status) => status.replace(" ", "-");

function App() {
  const params = new URLSearchParams(window.location.search);
  const customerMode = params.get("vista") === "cliente" || params.has("mesa");
  const tableParam = Number(params.get("mesa") || 1);
  const [state, setState] = useState(loadState);
  const [page, setPage] = useState("dashboard");
  const [mobileNav, setMobileNav] = useState(false);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("todas");
  const [toast, setToast] = useState("");
  const [modal, setModal] = useState(null);
  const [customerSent, setCustomerSent] = useState(false);
  const [customerType, setCustomerType] = useState("atencion");
  const [customerNote, setCustomerNote] = useState("");
  const [newStaff, setNewStaff] = useState({ name: "", role: "Camarero" });

  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }, [state]);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 2800);
    return () => clearTimeout(t);
  }, [toast]);

  const update = (fn) => setState(current => fn(structuredClone(current)));
  const notify = (message) => setToast(message);
  const activeRequests = state.requests.filter(r => r.status !== "atendida");
  const pending = state.requests.filter(r => r.status === "pendiente");
  const inProgress = state.requests.filter(r => r.status === "en proceso");
  const todayCount = state.requests.length;
  const average = state.requests.length ? Math.round(state.requests.reduce((sum, r) => sum + Math.max(1, (Date.now() - r.createdAt) / 60000), 0) / state.requests.length) : 0;

  const createRequest = (table, type, note = "") => {
    update(s => {
      s.requests.unshift({ id: Date.now(), table, type, note: note || requestLabel(type), status: "pendiente", createdAt: Date.now(), assigned: "Sin asignar" });
      const t = s.tables.find(x => x.id === table);
      if (t) t.status = "solicitando";
      return s;
    });
    notify("Solicitud enviada al equipo");
  };
  const changeRequest = (id, status, assigned) => {
    update(s => {
      const req = s.requests.find(r => r.id === id);
      if (req) {
        req.status = status;
        if (assigned) req.assigned = assigned;
        if (status === "atendida") {
          const openForTable = s.requests.some(r => r.table === req.table && r.id !== id && r.status !== "atendida");
          if (!openForTable) {
            const table = s.tables.find(t => t.id === req.table);
            if (table) table.status = "ocupada";
          }
        } else {
          const table = s.tables.find(t => t.id === req.table);
          if (table) table.status = "solicitando";
        }
      }
      return s;
    });
    notify(status === "atendida" ? "Solicitud marcada como atendida" : "Solicitud actualizada");
  };

  if (customerMode) {
    const table = state.tables.find(t => t.id === tableParam);
    return <CustomerView table={table} tableId={tableParam} sent={customerSent} setSent={setCustomerSent}
      type={customerType} setType={setCustomerType} note={customerNote} setNote={setCustomerNote}
      onSend={() => { createRequest(tableParam, customerType, customerNote); setCustomerSent(true); }} />;
  }

  const nav = [
    { id: "dashboard", label: "Resumen", icon: LayoutDashboard },
    { id: "solicitudes", label: "Solicitudes", icon: Bell, count: pending.length },
    { id: "mesas", label: "Mesas", icon: Table2 },
    { id: "equipo", label: "Equipo", icon: Users },
    { id: "reportes", label: "Reportes", icon: TrendingUp },
    { id: "configuracion", label: "Configuración", icon: Settings }
  ];

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
        <div className="brand"><div className="brand-mark">N</div><div><b>NEXO<span>.</span></b><small>RESTAURANT OS</small></div><button className="mobile-close" onClick={() => setMobileNav(false)}><X size={18}/></button></div>
        <div className="restaurant-switch"><div className="restaurant-avatar"><Utensils size={17}/></div><div><b>{state.restaurant.name}</b><small>{state.restaurant.subtitle}</small></div><ChevronDown size={15}/></div>
        <div className="nav-caption">MENÚ PRINCIPAL</div>
        <nav>{nav.map(item => <button key={item.id} className={`nav-item ${page === item.id ? "active" : ""}`} onClick={() => { setPage(item.id); setMobileNav(false); }}><item.icon size={18}/><span>{item.label}</span>{item.count > 0 && <em>{item.count}</em>}</button>)}</nav>
        <div className="sidebar-bottom"><div className="help-card"><div className="help-icon"><CircleHelp size={17}/></div><b>¿Necesitas ayuda?</b><p>Consulta la guía rápida de NEXO.</p><button onClick={() => notify("Centro de ayuda: próximamente")}>Ver ayuda <ArrowUpRight size={13}/></button></div><div className="profile"><div className="profile-avatar">VC</div><div><b>Valentina Cruz</b><small>Administradora</small></div><MoreHorizontal size={18}/></div></div>
      </aside>

      <main className="main-area">
        <header className="topbar"><div className="top-left"><button className="mobile-menu" onClick={() => setMobileNav(true)}><Menu/></button><div className="breadcrumb">Workspace <span>/</span> <b>{nav.find(n => n.id === page)?.label || "Resumen"}</b></div></div><div className="top-actions"><div className="live-indicator"><i/> Sistema activo</div><button className="icon-button" title="Notificaciones" onClick={() => setPage("solicitudes")}><Bell size={18}/>{pending.length > 0 && <i className="notification-dot"/>}</button><div className="top-avatar">VC</div></div></header>

        <div className="content">
          {page === "dashboard" && <Dashboard state={state} pending={pending} inProgress={inProgress} activeRequests={activeRequests} todayCount={todayCount} average={average} setPage={setPage} changeRequest={changeRequest} notify={notify} />}
          {page === "solicitudes" && <Requests state={state} search={search} setSearch={setSearch} filter={filter} setFilter={setFilter} changeRequest={changeRequest} />}
          {page === "mesas" && <Tables state={state} setModal={setModal} createRequest={createRequest} notify={notify} />}
          {page === "equipo" && <Team state={state} setModal={setModal} update={update} notify={notify} />}
          {page === "reportes" && <Reports state={state} average={average} />}
          {page === "configuracion" && <SettingsPage state={state} update={update} notify={notify} />}
        </div>
      </main>

      {modal && <Modal modal={modal} setModal={setModal} state={state} update={update} notify={notify} newStaff={newStaff} setNewStaff={setNewStaff} />}
      {toast && <div className="toast"><CircleCheck size={17}/>{toast}</div>}
    </div>
  );
}

function PageHeading({ eyebrow, title, desc, action }) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{desc}</p></div>{action}</div>;
}
function StatCard({ label, value, delta, icon: Icon, tone = "blue", foot }) {
  return <div className="stat-card"><div className="stat-top"><span>{label}</span><div className={`stat-icon ${tone}`}><Icon size={18}/></div></div><div className="stat-value">{value}</div><div className="stat-foot">{delta && <span className="positive"><TrendingUp size={13}/> {delta}</span>}<span>{foot}</span></div></div>;
}
function Dashboard({ state, pending, inProgress, activeRequests, todayCount, average, setPage, changeRequest, notify }) {
  const recent = state.requests.slice(0, 5);
  const occupied = state.tables.filter(t => t.status !== "libre").length;
  return <>
    <PageHeading eyebrow="SÁBADO, 14 DE NOVIEMBRE" title="¡Buen día, Valentina!" desc="Aquí tienes el estado de tu restaurante en este momento." action={<button className="button primary" onClick={() => setPage("mesas")}><Plus size={16}/> Nueva solicitud</button>}/>
    <div className="welcome-banner"><div className="banner-copy"><div className="banner-pill"><Sparkles size={13}/> NEXO INSIGHTS</div><h2>Tu servicio, conectado.</h2><p>Gestiona cada solicitud y mantén a tu equipo coordinado desde un solo lugar.</p><button onClick={() => setPage("solicitudes")}>Ver solicitudes <ArrowUpRight size={15}/></button></div><div className="banner-art"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="phone-art"><div className="phone-speaker"/><div className="phone-screen"><div className="phone-logo">N.</div><div className="phone-line"/><div className="phone-button"><Bell size={17}/></div><div className="phone-line short"/></div></div><div className="float-card"><Check size={14}/> Atención confirmada</div></div></div>
    <div className="stats-grid">
      <StatCard label="Solicitudes pendientes" value={pending.length} delta={pending.length ? "Requieren atención" : "Todo al día"} icon={Bell} tone="orange" foot="Por gestionar"/>
      <StatCard label="En proceso" value={inProgress.length} icon={Timer} tone="purple" foot="Atención del equipo"/>
      <StatCard label="Mesas activas" value={`${occupied}/${state.tables.length}`} icon={Table2} tone="blue" foot="Mesas con actividad"/>
      <StatCard label="Solicitudes registradas" value={todayCount} icon={Activity} delta="Actividad total" tone="green" foot="En esta demostración"/>
    </div>
    <div className="dashboard-grid"><section className="panel requests-panel"><div className="panel-heading"><div><h3>Solicitudes recientes</h3><p>Últimos avisos enviados por tus clientes</p></div><button className="text-button" onClick={() => setPage("solicitudes")}>Ver todas <ArrowUpRight size={14}/></button></div>
      {recent.length ? <div className="request-list">{recent.map(r => <RequestRow key={r.id} request={r} changeRequest={changeRequest}/>)}</div> : <EmptyState text="Todavía no hay solicitudes."/>}
    </section><section className="panel"><div className="panel-heading"><div><h3>Estado de las mesas</h3><p>Vista general del salón</p></div><button className="more-button" onClick={() => setPage("mesas")}><MoreHorizontal/></button></div><div className="occupancy"><div className="occupancy-number">{Math.round(occupied / Math.max(1, state.tables.length) * 100)}<small>%</small></div><div><b>Ocupación / actividad</b><p>{occupied} de {state.tables.length} mesas con actividad</p></div></div><div className="progress-track"><div style={{width: `${occupied / Math.max(1, state.tables.length) * 100}%`}}/></div><div className="legend"><span><i className="dot free"/> Libre</span><span><i className="dot busy"/> Activa</span><span><i className="dot alert"/> Solicitud</span></div><div className="quick-actions"><button onClick={() => setPage("mesas")}><QrCode size={17}/> Ver códigos QR</button><button onClick={() => setPage("equipo")}><Users size={17}/> Gestionar equipo</button></div></section></div>
    <div className="bottom-note"><ShieldCheck size={16}/> <span>Tu panel está actualizado. Los datos de esta demo se guardan en este navegador.</span><button onClick={() => notify("Datos locales guardados automáticamente.")}>Detalles</button></div>
  </>;
}
function RequestRow({ request, changeRequest }) {
  return <div className="request-row"><div className={`request-type-icon ${request.type}`} >{request.type === "cuenta" ? <CreditCard size={17}/> : request.type === "pedido" ? <Utensils size={17}/> : <Bell size={17}/>}</div><div className="request-main"><b>Mesa {String(request.table).padStart(2,"0")} <span>· {requestLabel(request.type)}</span></b><small>{request.note} · {timeAgo(request.createdAt)}</small></div><StatusPill status={request.status}/><div className="request-row-actions">{request.status !== "atendida" && <button className="tiny-action" title="Marcar atendida" onClick={() => changeRequest(request.id, "atendida")}><Check size={15}/></button>}</div></div>;
}
function StatusPill({ status }) {
  const labels = { pendiente: "Pendiente", "en proceso": "En proceso", atendida: "Atendida" };
  return <span className={`status-pill ${statusClass(status)}`}><i/>{labels[status] || status}</span>;
}
function Requests({ state, search, setSearch, filter, setFilter, changeRequest }) {
  const list = state.requests.filter(r => (filter === "todas" || r.status === filter) && (`${r.table} ${r.note} ${requestLabel(r.type)} ${r.assigned}`.toLowerCase().includes(search.toLowerCase())));
  return <>
    <PageHeading eyebrow="CENTRO DE OPERACIONES" title="Solicitudes" desc="Recibe, organiza y resuelve las solicitudes de tus mesas." action={<button className="button secondary" onClick={() => window.location.href = `${window.location.origin}${window.location.pathname}?mesa=1`}><Smartphone size={16}/> Vista cliente</button>}/>
    <div className="toolbar"><div className="search-box"><Search size={17}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por mesa, tipo o responsable..."/></div><div className="filter-wrap"><Filter size={16}/><select value={filter} onChange={e => setFilter(e.target.value)}><option value="todas">Todas las solicitudes</option><option value="pendiente">Pendientes</option><option value="en proceso">En proceso</option><option value="atendida">Atendidas</option></select></div></div>
    <section className="panel table-panel"><div className="panel-heading"><div><h3>Bandeja de solicitudes <span className="count-badge">{list.length}</span></h3><p>Gestiona el flujo de atención en tiempo real dentro de esta sesión.</p></div></div>
      <div className="data-table"><div className="table-head request-table-head"><span>MESA / SOLICITUD</span><span>HORA</span><span>RESPONSABLE</span><span>ESTADO</span><span>ACCIÓN</span></div>
      {list.map(r => <div className="table-line request-table-line" key={r.id}><div className="table-request-cell"><div className={`request-type-icon ${r.type}`}>{r.type === "cuenta" ? <CreditCard size={16}/> : r.type === "pedido" ? <Utensils size={16}/> : <Bell size={16}/>}</div><div><b>Mesa {String(r.table).padStart(2,"0")}</b><small>{requestLabel(r.type)}{r.note && r.note !== requestLabel(r.type) ? ` · ${r.note}` : ""}</small></div></div><span className="muted-cell">{fmtTime(r.createdAt)}</span><span className="muted-cell">{r.assigned}</span><span><StatusPill status={r.status}/></span><div className="action-cell">{r.status === "pendiente" && <button className="button small secondary" onClick={() => changeRequest(r.id, "en proceso", state.staff.find(s => s.active && s.role !== "Administradora")?.name || "Equipo")}>Tomar</button>}{r.status === "en proceso" && <button className="button small primary" onClick={() => changeRequest(r.id, "atendida")}>Resolver</button>}{r.status === "atendida" && <span className="done-label"><CheckCheck size={15}/> Listo</span>}</div></div>)}
      {!list.length && <EmptyState text="No encontramos solicitudes con estos filtros."/>}</div>
    </section>
  </>;
}
function Tables({ state, setModal, createRequest, notify }) {
  const [zone, setZone] = useState("Todas");
  const [selected, setSelected] = useState(null);
  const tables = state.tables.filter(t => zone === "Todas" || t.zone === zone);
  const table = state.tables.find(t => t.id === selected);
  const tableRequests = state.requests.filter(r => r.table === selected && r.status !== "atendida");
  return <>
    <PageHeading eyebrow="DISTRIBUCIÓN DEL RESTAURANTE" title="Gestión de mesas" desc="Consulta el estado de cada mesa y accede a su experiencia QR." action={<button className="button primary" onClick={() => setModal({type:"table"})}><Plus size={16}/> Agregar mesa</button>}/>
    <div className="toolbar"><div className="zone-tabs">{["Todas","Terraza","Salón"].map(z => <button key={z} className={zone === z ? "selected" : ""} onClick={() => setZone(z)}>{z}</button>)}</div><div className="legend"><span><i className="dot free"/> Libre</span><span><i className="dot busy"/> Activa</span><span><i className="dot alert"/> Solicitud</span></div></div>
    <div className="tables-layout"><section className="tables-grid">{tables.map(t => <button key={t.id} className={`table-card ${t.status} ${selected === t.id ? "chosen" : ""}`} onClick={() => setSelected(t.id)}><div className="table-card-top"><span>{t.zone}</span><MoreHorizontal size={16}/></div><div className="table-illustration"><div className="chair c1"/><div className="chair c2"/><div className="chair c3"/><div className="chair c4"/><div className="table-circle">{String(t.id).padStart(2,"0")}</div></div><b>Mesa {String(t.id).padStart(2,"0")}</b><small>{t.seats} personas</small><span className={`table-status ${t.status}`}>{t.status === "libre" ? "Disponible" : t.status === "solicitando" ? "Solicitud activa" : "En servicio"}</span></button>)}</section>
      <aside className="panel table-detail">{table ? <><div className="detail-head"><div><div className="eyebrow">DETALLE DE MESA</div><h3>Mesa {String(table.id).padStart(2,"0")}</h3></div><button className="icon-button" onClick={() => setSelected(null)}><X size={17}/></button></div><div className="detail-facts"><div><small>Zona</small><b>{table.zone}</b></div><div><small>Capacidad</small><b>{table.seats} personas</b></div><div><small>Estado</small><b>{table.status === "libre" ? "Disponible" : table.status === "solicitando" ? "Solicitud activa" : "En servicio"}</b></div></div><div className="qr-preview"><QrCode size={68}/><b>QR de Mesa {table.id}</b><small>Escanea para solicitar atención</small></div><button className="button primary full" onClick={() => { const url = `${window.location.origin}${window.location.pathname}?mesa=${table.id}`; navigator.clipboard?.writeText(url); notify("Enlace QR copiado (si el navegador lo permite)"); }}><Copy size={15}/> Copiar enlace QR</button><button className="button secondary full" onClick={() => window.open(`${window.location.pathname}?mesa=${table.id}`, "_blank")}>Abrir vista cliente <ExternalLink size={14}/></button><div className="detail-requests"><b>Solicitudes abiertas ({tableRequests.length})</b>{tableRequests.length ? tableRequests.map(r => <div key={r.id} className="mini-request"><span>{requestLabel(r.type)}</span><StatusPill status={r.status}/></div>) : <p>No hay solicitudes abiertas.</p>}</div></> : <div className="detail-empty"><Table2 size={30}/><b>Selecciona una mesa</b><p>Consulta sus detalles, estado y enlace de acceso QR.</p></div>}</aside></div>
  </>;
}
function Team({ state, setModal, update, notify }) {
  return <>
    <PageHeading eyebrow="PERSONAS Y OPERACIÓN" title="Equipo de trabajo" desc="Administra a las personas que participan en la atención." action={<button className="button primary" onClick={() => setModal({type:"staff"})}><Plus size={16}/> Agregar persona</button>}/>
    <div className="stats-grid team-stats"><StatCard label="Personas registradas" value={state.staff.length} icon={Users} tone="blue" foot="Equipo total"/><StatCard label="Activas" value={state.staff.filter(s=>s.active).length} icon={CircleCheck} tone="green" foot="Disponibles"/><StatCard label="Roles" value={new Set(state.staff.map(s=>s.role)).size} icon={ShieldCheck} tone="purple" foot="Perfiles configurados"/></div>
    <section className="panel table-panel"><div className="panel-heading"><div><h3>Mi equipo</h3><p>Personas registradas en el espacio de trabajo.</p></div></div><div className="team-list">{state.staff.map((person, i) => <div className="team-row" key={person.id}><div className={`person-avatar avatar-${i%4}`}>{person.name.split(" ").map(n=>n[0]).slice(0,2).join("").toUpperCase()}</div><div className="person-info"><b>{person.name}</b><small>{person.role}</small></div><span className={`person-status ${person.active ? "active" : ""}`}><i/>{person.active ? "Activo" : "Inactivo"}</span><button className="button small secondary" onClick={() => { update(s => { const p=s.staff.find(x=>x.id===person.id); p.active=!p.active; return s; }); notify("Estado del equipo actualizado"); }}>{person.active ? "Desactivar" : "Activar"}</button></div>)}</div></section>
  </>;
}
function Reports({ state, average }) {
  const done = state.requests.filter(r=>r.status==="atendida").length;
  const total = state.requests.length;
  const byType = ["atencion","cuenta","pedido"].map(type => ({type, count:state.requests.filter(r=>r.type===type).length}));
  const max = Math.max(1,...byType.map(x=>x.count));
  return <>
    <PageHeading eyebrow="ANÁLISIS DEL SERVICIO" title="Reportes" desc="Indicadores básicos de la actividad registrada en esta demostración." action={<button className="button secondary" onClick={() => { const csv = ["id,mesa,tipo,estado,responsable,hora", ...state.requests.map(r=>`${r.id},${r.table},${r.type},${r.status},${r.assigned},${fmtTime(r.createdAt)}`)].join("\n"); const a=document.createElement("a"); a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"})); a.download="nexo-reporte.csv"; a.click(); URL.revokeObjectURL(a.href); }}><Download size={16}/> Exportar CSV</button>}/>
    <div className="stats-grid"><StatCard label="Solicitudes totales" value={total} icon={ClipboardList} tone="blue" foot="Registros locales"/><StatCard label="Solicitudes resueltas" value={done} icon={CheckCheck} tone="green" foot="Marcadas atendidas"/><StatCard label="Pendientes" value={state.requests.filter(r=>r.status!=="atendida").length} icon={Clock3} tone="orange" foot="Por resolver"/><StatCard label="Antigüedad media" value={`${average} min`} icon={Timer} tone="purple" foot="Cálculo orientativo"/></div>
    <div className="reports-grid"><section className="panel"><div className="panel-heading"><div><h3>Solicitudes por tipo</h3><p>Distribución de los registros actuales</p></div></div><div className="bar-chart">{byType.map(item=><div className="bar-row" key={item.type}><div className="bar-label"><span>{requestLabel(item.type)}</span><b>{item.count}</b></div><div className="bar-track"><div style={{width:`${item.count/max*100}%`}}/></div></div>)}</div></section><section className="panel report-summary"><div className="panel-heading"><div><h3>Estado del servicio</h3><p>Resolución de solicitudes</p></div></div><div className="donut" style={{"--progress":`${total ? done/total*100 : 0}%`}}><div><b>{total ? Math.round(done/total*100) : 0}%</b><small>Resueltas</small></div></div><p className="report-caption">{done} de {total} solicitudes marcadas como atendidas.</p></section></div>
  </>;
}
function SettingsPage({ state, update, notify }) {
  const [name, setName] = useState(state.restaurant.name);
  return <>
    <PageHeading eyebrow="PERSONALIZACIÓN" title="Configuración" desc="Ajusta los datos principales del espacio de trabajo."/>
    <div className="settings-layout"><section className="panel settings-panel"><div className="panel-heading"><div><h3>Información del restaurante</h3><p>Estos datos identifican tu espacio de trabajo.</p></div></div><label className="field-label">Nombre comercial<input value={name} onChange={e=>setName(e.target.value)}/></label><label className="field-label">Tipo de negocio<input value={state.restaurant.subtitle} onChange={e=>update(s=>{s.restaurant.subtitle=e.target.value;return s;})}/></label><label className="field-label">Moneda<select value={state.restaurant.currency} onChange={e=>update(s=>{s.restaurant.currency=e.target.value;return s;})}><option value="USD">USD — Dólar estadounidense</option><option value="VES">VES — Bolívar</option><option value="CLP">CLP — Peso chileno</option></select></label><button className="button primary" onClick={()=>{update(s=>{s.restaurant.name=name;return s;});notify("Datos del restaurante guardados");}}>Guardar cambios</button></section><section className="panel settings-panel"><div className="panel-heading"><div><h3>Preferencias de operación</h3><p>Opciones locales de esta demostración.</p></div></div><ToggleRow title="Sonido de notificaciones" desc="Indica si se habilitarán avisos sonoros cuando se conecte el sistema real." value={state.settings.sound} onChange={v=>update(s=>{s.settings.sound=v;return s;})}/><ToggleRow title="Asignación automática" desc="Prepara la preferencia para asignar solicitudes al equipo." value={state.settings.autoAssign} onChange={v=>update(s=>{s.settings.autoAssign=v;return s;})}/><div className="service-hours"><Clock3 size={17}/><div><b>Horario de servicio</b><small>{state.settings.serviceHours}</small></div></div></section><section className="panel danger-zone"><div className="panel-heading"><div><h3>Zona de mantenimiento</h3><p>Acciones sobre los datos guardados en este navegador.</p></div></div><button className="button danger" onClick={()=>{if(confirm("¿Seguro que deseas restaurar los datos de demostración?")){localStorage.removeItem(STORAGE_KEY);window.location.reload();}}}><RefreshCw size={15}/> Restaurar datos de demo</button><small>Esta acción elimina los cambios locales de esta demostración.</small></section></div>
  </>;
}
function ToggleRow({ title, desc, value, onChange }) {
  return <div className="toggle-row"><div><b>{title}</b><p>{desc}</p></div><button className={`toggle ${value?"on":""}`} onClick={()=>onChange(!value)} aria-label={title}><i/></button></div>;
}
function EmptyState({ text }) { return <div className="empty-state"><ClipboardList size={26}/><p>{text}</p></div>; }
function Modal({ modal, setModal, state, update, notify, newStaff, setNewStaff }) {
  const [seats,setSeats]=useState("4"), [zone,setZone]=useState("Salón");
  return <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setModal(null);}}><div className="modal"><div className="modal-head"><h3>{modal.type==="staff"?"Agregar persona":"Agregar mesa"}</h3><button className="icon-button" onClick={()=>setModal(null)}><X size={18}/></button></div>{modal.type==="staff"?<><label className="field-label">Nombre<input value={newStaff.name} onChange={e=>setNewStaff({...newStaff,name:e.target.value})} placeholder="Nombre y apellido"/></label><label className="field-label">Rol<select value={newStaff.role} onChange={e=>setNewStaff({...newStaff,role:e.target.value})}><option>Camarero</option><option>Camarera</option><option>Administradora</option><option>Supervisor</option></select></label><button className="button primary full" onClick={()=>{if(!newStaff.name.trim())return;update(s=>{s.staff.push({id:Date.now(),name:newStaff.name.trim(),role:newStaff.role,active:true});return s;});setNewStaff({name:"",role:"Camarero"});setModal(null);notify("Persona agregada al equipo");}}>Agregar al equipo</button></>:<><label className="field-label">Capacidad<select value={seats} onChange={e=>setSeats(e.target.value)}><option value="2">2 personas</option><option value="4">4 personas</option><option value="6">6 personas</option><option value="8">8 personas</option></select></label><label className="field-label">Zona<select value={zone} onChange={e=>setZone(e.target.value)}><option>Salón</option><option>Terraza</option><option>Barra</option></select></label><button className="button primary full" onClick={()=>{update(s=>{s.tables.push({id:Math.max(0,...s.tables.map(t=>t.id))+1,seats:Number(seats),zone,status:"libre"});return s;});setModal(null);notify("Mesa agregada");}}>Crear mesa</button></>}</div></div>;
}
function CustomerView({ table, tableId, sent, setSent, type, setType, note, setNote, onSend }) {
  return <div className="customer-page"><div className="customer-top"><div className="brand-mark">N</div><b>NEXO<span>.</span></b><span className="customer-restaurant">{table?.zone || "Restaurante"} · {table?.id ? "Servicio en mesa" : "Atención digital"}</span></div><div className="customer-card"><div className="customer-welcome-icon"><Utensils size={23}/></div><div className="eyebrow">BIENVENIDO/A</div><h1>Estamos para atenderte.</h1><p>Selecciona lo que necesitas y enviaremos tu solicitud a nuestro equipo.</p><div className="customer-table">MESA <b>{String(tableId).padStart(2,"0")}</b></div>{sent ? <div className="success-panel"><div><CheckCheck size={27}/></div><h2>¡Solicitud enviada!</h2><p>El equipo recibió tu aviso. En breve se acercará a tu mesa.</p><button className="button secondary full" onClick={()=>{setSent(false);setNote("");}}>Enviar otra solicitud</button></div> : <><div className="customer-options"><button className={type==="atencion"?"chosen":""} onClick={()=>setType("atencion")}><span><Bell size={19}/></span><b>Llamar al camarero</b><small>Necesito ayuda o atención</small></button><button className={type==="cuenta"?"chosen":""} onClick={()=>setType("cuenta")}><span><Wallet size={19}/></span><b>Solicitar la cuenta</b><small>Quiero pagar mi consumo</small></button><button className={type==="pedido"?"chosen":""} onClick={()=>setType("pedido")}><span><Utensils size={19}/></span><b>Hacer un pedido</b><small>Quiero pedir algo más</small></button></div><label className="field-label customer-note">Mensaje adicional <span>(opcional)</span><textarea value={note} onChange={e=>setNote(e.target.value)} placeholder="Escribe aquí si necesitas algo específico..." rows="3"/></label><button className="button customer-send full" onClick={onSend}>Enviar solicitud <ArrowUpRight size={17}/></button></>}<div className="customer-secure"><ShieldCheck size={14}/> Tu solicitud se envía de forma segura al restaurante.</div></div><footer>Atención conectada por <b>NEXO.</b></footer></div>;
}

export default App;
